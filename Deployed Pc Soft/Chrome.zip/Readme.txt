1. Extract the file inside "D:/"
2. Install Runtime
3. Install Chrome Extension
4. Run Hist Installer bat file.